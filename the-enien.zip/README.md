# The Enien (Godot 4.3, Android)
Upload ZIP ini ke root repo GitHub, buat file .github/workflows/build.yml (isi dari build.yml), lalu buka tab Actions -> Build The Enien -> Artifacts -> APK.
