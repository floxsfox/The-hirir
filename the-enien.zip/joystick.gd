extends Control

var vec = Vector2.ZERO
var idx = -1
var knob = Vector2.ZERO

func _input(e) -> void:
	if e is InputEventScreenTouch:
		if e.pressed and idx == -1 and get_global_rect().has_point(e.position):
			idx = e.index
			upd(e.position)
		elif not e.pressed and e.index == idx:
			idx = -1
			vec = Vector2.ZERO
			knob = Vector2.ZERO
			queue_redraw()
	elif e is InputEventScreenDrag and e.index == idx:
		upd(e.position)

func upd(p: Vector2) -> void:
	var r = size.x / 2.0
	knob = (p - (global_position + size / 2.0)).limit_length(r)
	vec = knob / r
	if vec.length() < 0.15:
		vec = Vector2.ZERO
	queue_redraw()

func _draw() -> void:
	var c = size / 2.0
	draw_circle(c, size.x / 2.0, Color(1, 1, 1, 0.08))
	draw_arc(c, size.x / 2.0, 0, TAU, 48, Color(1, 1, 1, 0.35), 3.0)
	draw_circle(c + knob, 45.0, Color(1, 1, 1, 0.4))
