# Kredit aset (diunduh otomatis oleh fetch_assets.py)
- Model & tekstur: Poly Haven (polyhaven.com) - CC0.
- Musik/SFX: OpenGameArt.org - CC0: techiew (Ambient horror), congusbongus (A lurking evil), Oiboo (Door Open SFX), Ogrebane (Monster Sound Pack), rubberduck (100 CC0 metal and wood SFX), footsteps 01-06.
- "freezer.ogg" (Abandoned passages horror ambience loop): cek lisensi di halaman OpenGameArt-nya sebelum rilis.
