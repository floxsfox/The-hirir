#!/usr/bin/env python3
"""Unduh aset CC0 dari internet (Poly Haven + OpenGameArt). Dijalankan otomatis oleh GitHub Actions."""
import json, os, shutil, urllib.request, zipfile, glob

UA = {"User-Agent": "Mozilla/5.0 (TheEnien asset fetch)"}
OGA = "https://opengameart.org/sites/default/files/"

def get(url, dest):
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        print("SKIP", dest)
        return True
    os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
    for i in range(3):
        try:
            data = urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=90).read()
            open(dest, "wb").write(data)
            print("OK  ", dest)
            return True
        except Exception as e:
            print("RETRY", i + 1, url, e)
    print("FAIL", url)
    return False

def ph(asset):
    r = urllib.request.Request("https://api.polyhaven.com/files/" + asset, headers=UA)
    return json.load(urllib.request.urlopen(r, timeout=60))

MODELS = ["ClassicNightstand_01", "ClassicConsole_01", "GothicCabinet_01", "WoodenTable_03",
          "WoodenChair_01", "painted_wooden_chair_02", "painted_wooden_table", "chinese_tea_table"]
TEXTURES = ["damaged_plaster", "worn_tile_floor", "wood_peeling_paint_weathered", "red_plaster_weathered"]

for m in MODELS:
    try:
        g = ph(m)["gltf"]["1k"]["gltf"]
        base = "assets/models/%s/" % m
        get(g["url"], base + "model.gltf")
        for rel, info in g.get("include", {}).items():
            get(info["url"], base + rel)
    except Exception as e:
        print("FAIL model", m, e)

for t in TEXTURES:
    try:
        d = ph(t)
        get(d["Diffuse"]["1k"]["jpg"]["url"], "assets/tex/%s_diff.jpg" % t)
        get(d["nor_gl"]["1k"]["jpg"]["url"], "assets/tex/%s_nor.jpg" % t)
    except Exception as e:
        print("FAIL tex", t, e)

A = "assets/audio/"
get(OGA + "freezer.ogg", A + "music_ambient.ogg")
get(OGA + "evil.ogg", A + "music_chase.ogg")
get(OGA + "ambient_horror.ogg", A + "scare.ogg")
get(OGA + "door_open.wav", A + "door.wav")
for i in range(1, 7):
    get(OGA + "0%d-footstep.ogg" % i, A + "step%d.ogg" % i)

def from_zip(url, key, out):
    tmp = "_tmp.zip"
    if not get(url, tmp):
        return
    try:
        with zipfile.ZipFile(tmp) as z:
            z.extractall("_tmpz")
        files = [f for f in glob.glob("_tmpz/**/*", recursive=True) if f.lower().endswith((".wav", ".ogg"))]
        pick = [f for f in files if key in os.path.basename(f).lower()] or files
        if pick:
            ext = os.path.splitext(pick[0])[1]
            shutil.copy(pick[0], A + out + ext)
            print("OK  ", A + out + ext, "<-", pick[0])
    except Exception as e:
        print("FAIL zip", url, e)
    shutil.rmtree("_tmpz", ignore_errors=True)
    os.remove(tmp)

from_zip(OGA + "monster-sounds-volume-2.zip", "growl", "growl")
from_zip(OGA + "100-CC0-wood-metal-SFX.zip", "key", "key")
