extends Node3D
# THE ENIEN - horror puzzle Android (Godot 4.3)

const AS = "res://assets/"
const CODE = "3817"

var player: CharacterBody3D
var cam: Camera3D
var enemy: CharacterBody3D
var ui: CanvasLayer
var joy: Control
var hud: Label
var msg: Label
var use_btn: Button
var crouch_btn: Button
var menu_btn: Button
var menu: Panel
var pad: Panel
var padlbl: Label
var chase_p: AudioStreamPlayer
var flick: OmniLight3D
var objs: Array = []
var inv: Array = []
var cur = null
var code_obj = null
var yaw = 0.0
var pitch = 0.0
var crouch = false
var look_idx = -1
var msg_t = 0.0
var step_t = 0.0
var lost = 0.0
var zlim = -10.0
var ending = false
var enemy_on = false
var chasing = false
var aware = 0.0
var wake_t = -1.0
var last_seen = Vector3.ZERO
var wp = Vector3.ZERO
var entered = ""

func _ready() -> void:
	randomize()
	build_world()
	build_player()
	build_enemy()
	build_ui()
	loop_player("music_ambient", -8.0)
	chase_p = loop_player("music_chase", -80.0)
	say("Temukan jalan keluar. Jangan sampai Enien menemukanmu.", 5.0)

# ---------- aset ----------
func tex(n: String, sc: float = 0.5) -> StandardMaterial3D:
	var m = StandardMaterial3D.new()
	var p = AS + "tex/" + n
	if ResourceLoader.exists(p + "_diff.jpg"):
		m.albedo_texture = load(p + "_diff.jpg")
		if ResourceLoader.exists(p + "_nor.jpg"):
			m.normal_enabled = true
			m.normal_texture = load(p + "_nor.jpg")
	else:
		m.albedo_color = Color(0.25, 0.22, 0.2)
	m.uv1_triplanar = true
	m.uv1_scale = Vector3.ONE * sc
	return m

func snd(n: String):
	for e in ["ogg", "wav", "mp3"]:
		var p = AS + "audio/%s.%s" % [n, e]
		if ResourceLoader.exists(p):
			return load(p)
	return null

func play(n: String, db: float = 0.0) -> void:
	var s = snd(n)
	if s == null:
		return
	var p = AudioStreamPlayer.new()
	p.stream = s
	p.volume_db = db
	add_child(p)
	p.play()
	p.finished.connect(p.queue_free)

func loop_player(n: String, db: float) -> AudioStreamPlayer:
	var p = AudioStreamPlayer.new()
	var s = snd(n)
	if s != null:
		if s is AudioStreamOggVorbis:
			s.loop = true
		p.stream = s
		p.volume_db = db
		add_child(p)
		p.play()
	return p

# ---------- dunia ----------
func box(pos: Vector3, sz: Vector3, mat: Material) -> StaticBody3D:
	var b = StaticBody3D.new()
	b.position = pos
	var mi = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = sz
	mi.mesh = bm
	mi.material_override = mat
	b.add_child(mi)
	var cs = CollisionShape3D.new()
	var sh = BoxShape3D.new()
	sh.size = sz
	cs.shape = sh
	b.add_child(cs)
	add_child(b)
	return b

func furn(model: String, pos: Vector3, ry: float, sz: Vector3) -> Node3D:
	var n = Node3D.new()
	n.position = pos
	n.rotation_degrees.y = ry
	var p = AS + "models/" + model + "/model.gltf"
	if ResourceLoader.exists(p):
		n.add_child(load(p).instantiate())
	else:
		var mi = MeshInstance3D.new()
		var bm = BoxMesh.new()
		bm.size = sz
		mi.mesh = bm
		mi.position.y = sz.y / 2.0
		mi.material_override = tex("wood_peeling_paint_weathered")
		n.add_child(mi)
	var sb = StaticBody3D.new()
	var cs = CollisionShape3D.new()
	var sh = BoxShape3D.new()
	sh.size = sz
	cs.shape = sh
	cs.position.y = sz.y / 2.0
	sb.add_child(cs)
	n.add_child(sb)
	add_child(n)
	return n

func reg(n: Node3D, label: String, kind: String, d: Dictionary) -> void:
	objs.append({"n": n, "label": label, "kind": kind, "d": d})

func lamp(pos: Vector3, e: float) -> OmniLight3D:
	var l = OmniLight3D.new()
	l.position = pos
	l.light_energy = e
	l.omni_range = 9.0
	l.light_color = Color(1.0, 0.78, 0.55)
	add_child(l)
	return l

func build_world() -> void:
	var env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color.BLACK
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.25, 0.27, 0.35)
	env.ambient_light_energy = 0.5
	env.fog_enabled = true
	env.fog_light_color = Color(0.03, 0.03, 0.04)
	env.fog_density = 0.06
	var we = WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var wall = tex("damaged_plaster")
	var wood = tex("wood_peeling_paint_weathered")
	box(Vector3(0, -0.1, -15), Vector3(8.4, 0.2, 30.4), tex("worn_tile_floor"))
	box(Vector3(0, 3.1, -15), Vector3(8.4, 0.2, 30.4), wood)
	box(Vector3(-4.1, 1.5, -15), Vector3(0.2, 3, 30.4), wall)
	box(Vector3(4.1, 1.5, -15), Vector3(0.2, 3, 30.4), wall)
	box(Vector3(0, 1.5, 0.1), Vector3(8.4, 3, 0.2), wall)
	box(Vector3(0, 1.5, -30.1), Vector3(8.4, 3, 0.2), wall)
	for z in [-10.0, -20.0]:
		box(Vector3(-2.5, 1.5, z), Vector3(3, 3, 0.2), wall)
		box(Vector3(2.5, 1.5, z), Vector3(3, 3, 0.2), wall)
	lamp(Vector3(0, 2.6, -5), 0.7)
	flick = lamp(Vector3(0, 2.6, -15), 0.8)
	lamp(Vector3(0, 2.6, -25), 0.6)
	# Ruang 1: laci nakas -> Kunci Perunggu
	var ns = furn("ClassicNightstand_01", Vector3(-3.4, 0, -2), 90, Vector3(0.6, 0.7, 0.5))
	reg(ns, "Periksa laci", "pick", {"give": "Kunci Perunggu", "text": "Di dalam laci ada Kunci Perunggu."})
	furn("painted_wooden_chair_02", Vector3(2.0, 0, -3), 200, Vector3(0.5, 0.9, 0.5))
	furn("painted_wooden_table", Vector3(2.4, 0, -7), 90, Vector3(1.0, 0.8, 2.4))
	var d1 = box(Vector3(0, 1.5, -10), Vector3(2, 3, 0.2), wood)
	reg(d1, "Buka pintu", "door", {"need": "Kunci Perunggu", "z": -20.0})
	# Ruang 2: konsol (petunjuk) -> lemari kode -> Sekring
	var cn = furn("ClassicConsole_01", Vector3(-3.4, 0, -13), 90, Vector3(0.6, 0.9, 1.4))
	reg(cn, "Baca catatan", "note", {"text": "Sobekan kertas: 'Tiga. Delapan. Satu. Tujuh.'"})
	var cb = furn("GothicCabinet_01", Vector3(3.3, 0, -17), -90, Vector3(1.3, 2.2, 0.7))
	reg(cb, "Lemari terkunci", "code", {"give": "Sekring"})
	furn("WoodenTable_03", Vector3(-1.5, 0, -16), 0, Vector3(1.3, 0.8, 0.8))
	furn("WoodenChair_01", Vector3(-2.2, 0, -18), 150, Vector3(0.5, 1.0, 0.5))
	var d2 = box(Vector3(0, 1.5, -20), Vector3(2, 3, 0.2), tex("red_plaster_weathered"))
	reg(d2, "Pintu listrik", "door", {"need": "Sekring", "z": -30.0})
	# Ruang 3: meja teh -> Kunci Emas -> gerbang
	var tt = furn("chinese_tea_table", Vector3(-3.0, 0, -24), 90, Vector3(0.8, 0.8, 0.8))
	reg(tt, "Periksa meja", "pick", {"give": "Kunci Emas", "text": "Kamu menemukan Kunci Emas!"})
	furn("painted_wooden_chair_02", Vector3(2.0, 0, -26), 20, Vector3(0.5, 0.9, 0.5))
	var ex = box(Vector3(0, 1.5, -29.9), Vector3(2, 3, 0.2), tex("red_plaster_weathered"))
	reg(ex, "Gerbang keluar", "exit", {"need": "Kunci Emas"})

func build_player() -> void:
	player = CharacterBody3D.new()
	player.position = Vector3(0, 0.05, -1)
	var cs = CollisionShape3D.new()
	var cap = CapsuleShape3D.new()
	cap.radius = 0.3
	cap.height = 1.7
	cs.shape = cap
	cs.position.y = 0.9
	player.add_child(cs)
	cam = Camera3D.new()
	cam.position.y = 1.6
	cam.fov = 75
	cam.near = 0.05
	player.add_child(cam)
	var sl = SpotLight3D.new()
	sl.spot_range = 16.0
	sl.spot_angle = 38.0
	sl.light_energy = 4.0
	cam.add_child(sl)
	add_child(player)

func build_enemy() -> void:
	enemy = CharacterBody3D.new()
	enemy.position = Vector3(0, 0.05, -17)
	enemy.visible = false
	enemy.collision_layer = 0
	var cs = CollisionShape3D.new()
	var cap = CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 2.2
	cs.shape = cap
	cs.position.y = 1.1
	enemy.add_child(cs)
	var mi = MeshInstance3D.new()
	var cm = CapsuleMesh.new()
	cm.radius = 0.35
	cm.height = 2.3
	mi.mesh = cm
	mi.position.y = 1.15
	var bm = StandardMaterial3D.new()
	bm.albedo_color = Color(0.02, 0.02, 0.03)
	mi.material_override = bm
	enemy.add_child(mi)
	for sx in [-0.12, 0.12]:
		var eye = MeshInstance3D.new()
		var sm = SphereMesh.new()
		sm.radius = 0.05
		sm.height = 0.1
		eye.mesh = sm
		eye.position = Vector3(sx, 1.95, -0.3)
		var em = StandardMaterial3D.new()
		em.albedo_color = Color.RED
		em.emission_enabled = true
		em.emission = Color.RED
		em.emission_energy_multiplier = 3.0
		eye.material_override = em
		enemy.add_child(eye)
	var l = OmniLight3D.new()
	l.light_color = Color(1, 0, 0)
	l.light_energy = 0.6
	l.omni_range = 4.0
	l.position.y = 1.9
	enemy.add_child(l)
	add_child(enemy)

# ---------- UI ----------
func mk_btn(t: String, ax: float, ay: float, ox: float, oy: float, w: float, h: float) -> Button:
	var b = Button.new()
	b.text = t
	b.focus_mode = Control.FOCUS_NONE
	b.anchor_left = ax
	b.anchor_right = ax
	b.anchor_top = ay
	b.anchor_bottom = ay
	b.offset_left = ox
	b.offset_right = ox + w
	b.offset_top = oy
	b.offset_bottom = oy + h
	b.add_theme_font_size_override("font_size", 26)
	ui.add_child(b)
	return b

func overlay(t: String, buttons: Array) -> Panel:
	var p = Panel.new()
	p.set_anchors_preset(Control.PRESET_FULL_RECT)
	var cc = CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	p.add_child(cc)
	var vb = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 16)
	cc.add_child(vb)
	var l = Label.new()
	l.text = t
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", 46)
	vb.add_child(l)
	for b in buttons:
		var bt = Button.new()
		bt.text = b[0]
		bt.custom_minimum_size = Vector2(360, 80)
		bt.add_theme_font_size_override("font_size", 30)
		bt.pressed.connect(b[1])
		vb.add_child(bt)
	ui.add_child(p)
	return p

func build_ui() -> void:
	ui = CanvasLayer.new()
	ui.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(ui)
	joy = Control.new()
	joy.set_script(load("res://joystick.gd"))
	joy.anchor_top = 1.0
	joy.anchor_bottom = 1.0
	joy.offset_left = 50
	joy.offset_right = 300
	joy.offset_top = -300
	joy.offset_bottom = -50
	ui.add_child(joy)
	hud = Label.new()
	hud.position = Vector2(20, 14)
	hud.add_theme_font_size_override("font_size", 24)
	ui.add_child(hud)
	msg = Label.new()
	msg.anchor_left = 0.2
	msg.anchor_right = 0.8
	msg.anchor_top = 1.0
	msg.anchor_bottom = 1.0
	msg.offset_top = -120
	msg.offset_bottom = -40
	msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	msg.add_theme_font_size_override("font_size", 26)
	ui.add_child(msg)
	crouch_btn = mk_btn("JONGKOK", 1.0, 0.5, -190, -70, 150, 140)
	crouch_btn.toggle_mode = true
	crouch_btn.toggled.connect(func(on): crouch = on)
	menu_btn = mk_btn("MENU", 1.0, 0.0, -170, 20, 150, 80)
	menu_btn.pressed.connect(open_menu)
	use_btn = mk_btn("", 1.0, 1.0, -300, -200, 260, 120)
	use_btn.pressed.connect(use)
	use_btn.visible = false
	menu = overlay("MENU", [["Lanjut", resume], ["Ulangi", restart], ["Keluar", quit]])
	menu.visible = false
	pad = overlay("Kunci Kode", [])
	var vb = pad.get_child(0).get_child(0)
	padlbl = Label.new()
	padlbl.text = "----"
	padlbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	padlbl.add_theme_font_size_override("font_size", 48)
	vb.add_child(padlbl)
	var g = GridContainer.new()
	g.columns = 3
	vb.add_child(g)
	for t in ["1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "OK"]:
		var b = Button.new()
		b.text = t
		b.custom_minimum_size = Vector2(110, 60)
		b.add_theme_font_size_override("font_size", 30)
		b.pressed.connect(pad_press.bind(t))
		g.add_child(b)
	var x = Button.new()
	x.text = "Tutup"
	x.pressed.connect(func(): pad.visible = false)
	vb.add_child(x)
	pad.visible = false

func open_menu() -> void:
	menu.visible = true
	get_tree().paused = true

func resume() -> void:
	menu.visible = false
	get_tree().paused = false

func restart() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()

func quit() -> void:
	get_tree().quit()

func say(t: String, secs: float = 3.0) -> void:
	msg.text = t
	msg_t = secs

# ---------- puzzle ----------
func pad_press(t: String) -> void:
	if t == "C":
		entered = ""
	elif t == "OK":
		if entered == CODE:
			pad.visible = false
			inv.append(code_obj["d"]["give"])
			objs.erase(code_obj)
			play("key")
			say("Lemari terbuka. Kamu mengambil Sekring.", 4.0)
		else:
			say("Kode salah.")
			entered = ""
	elif entered.length() < 4:
		entered += t
	padlbl.text = entered.rpad(4, "-")

func use() -> void:
	if cur == null or ending:
		return
	var o = cur
	var d: Dictionary = o["d"]
	match o["kind"]:
		"pick":
			inv.append(d["give"])
			objs.erase(o)
			play("key")
			say(d["text"], 4.0)
		"note":
			say(d["text"], 7.0)
		"door":
			if d["need"] in inv:
				play("door")
				o["n"].queue_free()
				objs.erase(o)
				say("Pintu terbuka.")
				zlim = min(zlim, d["z"])
				if not enemy_on and wake_t < 0.0:
					wake_t = 25.0
					say("Pintu terbuka. Rumah ini terasa seperti mengawasimu...", 5.0)
			else:
				say("Terkunci. Butuh: " + d["need"])
		"code":
			code_obj = o
			entered = ""
			padlbl.text = "----"
			pad.visible = true
		"exit":
			if d["need"] in inv:
				finish("KAMU BERHASIL KABUR")
			else:
				say("Gerbang terkunci. Butuh: " + d["need"])

func wake_enemy() -> void:
	enemy_on = true
	enemy.visible = true
	enemy.collision_layer = 1
	var best = Vector3(0, 0.05, -2)
	var bd = 0.0
	for i in 16:
		var p = Vector3(randf_range(-0.6, 0.6), 0.05, randf_range(zlim + 1.5, -1.5))
		var d = p.distance_to(player.global_position)
		if d > bd:
			bd = d
			best = p
	enemy.global_position = best
	new_wp()
	play("growl", -18.0)
	say("Ada sesuatu bergerak di dalam rumah...", 4.0)

func new_wp() -> void:
	wp = Vector3(randf_range(-3.0, 3.0), 0, randf_range(zlim + 1.5, -1.5))

func finish(t: String) -> void:
	ending = true
	overlay(t, [["Main lagi", restart], ["Keluar", quit]])

# ---------- loop ----------
func over_ui(p: Vector2) -> bool:
	for c in [joy, use_btn, crouch_btn, menu_btn, menu, pad]:
		if c.visible and c.get_global_rect().has_point(p):
			return true
	return false

func _input(e) -> void:
	if e is InputEventScreenTouch:
		if e.pressed and look_idx == -1 and e.position.x > 330 and not over_ui(e.position):
			look_idx = e.index
		elif not e.pressed and e.index == look_idx:
			look_idx = -1
	elif e is InputEventScreenDrag and e.index == look_idx:
		yaw -= e.relative.x * 0.004
		pitch = clamp(pitch - e.relative.y * 0.004, -1.2, 1.2)

func _process(dt: float) -> void:
	player.rotation.y = yaw
	cam.rotation.x = pitch
	hud.text = "Barang: " + (", ".join(PackedStringArray(inv)) if inv.size() > 0 else "-")
	if msg_t > 0.0:
		msg_t -= dt
		if msg_t <= 0.0:
			msg.text = ""
	if randf() < 0.03:
		flick.light_energy = randf_range(0.1, 0.9)
	cur = null
	var best = 2.8
	for o in objs:
		var v = o["n"].global_position + Vector3(0, 1.0, 0) - cam.global_position
		if v.length() < best and (-cam.global_transform.basis.z).dot(v.normalized()) > 0.6:
			best = v.length()
			cur = o
	use_btn.visible = cur != null and not ending
	if cur != null:
		use_btn.text = cur["label"]

func blocked() -> bool:
	for i in enemy.get_slide_collision_count():
		if abs(enemy.get_slide_collision(i).get_normal().y) < 0.5:
			return true
	return false

func los() -> bool:
	var q = PhysicsRayQueryParameters3D.create(enemy.global_position + Vector3(0, 1.5, 0), cam.global_position, 1, [enemy.get_rid(), player.get_rid()])
	return get_world_3d().direct_space_state.intersect_ray(q).is_empty()

func _physics_process(dt: float) -> void:
	if ending:
		return
	var mv = Basis(Vector3.UP, yaw) * Vector3(joy.vec.x, 0, joy.vec.y)
	var spd = 1.6 if crouch else 3.6
	player.velocity = Vector3(mv.x * spd, -9.0, mv.z * spd)
	player.move_and_slide()
	cam.position.y = lerp(cam.position.y, 1.0 if crouch else 1.6, 8.0 * dt)
	if mv.length() > 0.1:
		step_t -= dt
		if step_t <= 0.0:
			step_t = 0.9 if crouch else 0.55
			play("step%d" % (randi() % 6 + 1), -18.0 if crouch else -6.0)
	else:
		step_t = 0.0
	if wake_t > 0.0:
		wake_t -= dt
		if wake_t <= 0.0:
			wake_enemy()
	if not enemy_on:
		return
	var to = player.global_position - enemy.global_position
	to.y = 0
	var dist = to.length()
	var fwd = -enemy.global_transform.basis.z
	var facing = dist < 2.0 or fwd.dot(to.normalized()) > 0.5
	var moving = mv.length() > 0.1
	var see = facing and dist < (3.5 if crouch else 9.0) and los()
	var heard = moving and not crouch and dist < 4.0
	if see or heard:
		aware += dt * (1.6 if dist < 4.0 else 0.8)
		last_seen = player.global_position
	else:
		aware = max(0.0, aware - dt * 0.5)
	if chasing:
		if see or heard:
			lost = 0.0
		else:
			lost += dt
			if lost > 5.0:
				chasing = false
				aware = 0.0
				wp = last_seen
	elif aware >= 1.0:
		chasing = true
		lost = 0.0
		play("growl", -2.0)
	var tgt = player.global_position if chasing else wp
	var dir = tgt - enemy.global_position
	dir.y = 0
	if not chasing and (dir.length() < 1.0 or blocked()):
		new_wp()
	if dir.length() > 0.2:
		dir = dir.normalized()
		enemy.look_at(enemy.global_position + dir, Vector3.UP)
	var sp = 3.0 if chasing else 1.3
	enemy.velocity = Vector3(dir.x * sp, -9.0, dir.z * sp)
	enemy.move_and_slide()
	var near = clamp(1.0 - dist / 14.0, 0.0, 1.0)
	var vt = -4.0 if chasing else -60.0 + 40.0 * near
	chase_p.volume_db = lerp(chase_p.volume_db, vt, 2.0 * dt)
	if dist < 1.0:
		play("scare", 0.0)
		finish("ENIEN MENANGKAPMU")
